class VariablesVars {
	public transition = "0.5s ease-in-out";
	public fastTransition = "0.25s ease-in-out";
}

const Variables = new VariablesVars();
export default Variables;
