import { CSSObject } from "@emotion/react";

class StyleP {
	public mg18b: CSSObject = { marginBottom: 18 };
	public mg6b: CSSObject = { marginBottom: 6 };
}

export default new StyleP();
