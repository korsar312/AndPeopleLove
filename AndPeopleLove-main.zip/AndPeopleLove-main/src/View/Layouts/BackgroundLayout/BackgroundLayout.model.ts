import { IComponent } from "./index";

function BackgroundLayoutModel(props: IComponent) {
	const {} = props;

	return {};
}

export default BackgroundLayoutModel;
